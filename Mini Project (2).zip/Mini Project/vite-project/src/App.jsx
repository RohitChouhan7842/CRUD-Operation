import React from 'react'
import TaskProvider from './TaskProvider'

const App = () => {
  return (
    <div>
        <TaskProvider/>
    </div>
  )
}

export default App